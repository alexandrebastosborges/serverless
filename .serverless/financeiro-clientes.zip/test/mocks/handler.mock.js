const controllerMock = () => true

const event = {}
const context = {}

module.exports = {
  controllerMock,
  event,
  context,
}
