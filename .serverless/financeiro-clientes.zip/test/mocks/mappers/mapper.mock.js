const request = {
  status: 500,
  headers: {},
  data: "",
};

const error = {
  message: "",
};

module.exports = {
  request,
  error,
};
