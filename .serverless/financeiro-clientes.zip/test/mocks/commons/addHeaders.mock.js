const basicHeader = [
  {
    ["mock"]: "mockHeader",
  },
];

const overrideHeader = [
  {
    ["mock"]: "overrideHeader",
  },
];

const request = {
  headers: {},
};

module.exports = { basicHeader, request, overrideHeader };
